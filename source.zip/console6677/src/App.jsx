import Terminal from "./components/Terminal";

export default function App() {
  return (
    <div>
      <Terminal></Terminal>
    </div>
  )
}